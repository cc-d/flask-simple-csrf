METHOD = 'pbkdf2:sha256:10000'
SALT_LENGTH = 8
SECRET_CSRF_KEY = 'default-key-change-me-wMmeltW4mhwidorQRli6Oxx9VPXldz'
HTML_ELEM_NAME = 'simplecsrf'
